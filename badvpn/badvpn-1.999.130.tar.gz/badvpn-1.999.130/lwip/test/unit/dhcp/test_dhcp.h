#ifndef __TEST_DHCP_H__
#define __TEST_DHCP_H__

#include "../lwip_check.h"

Suite* dhcp_suite(void);

#endif
